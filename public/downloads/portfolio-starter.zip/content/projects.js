// ---------------------------------------------------------------------------
// Work items. THIS is the file you edit to add a new project.
//
// Add an object to the array and you get, for free:
//   - a card in the bento grid on the home page
//   - a detail page at /work/<slug>
//   - an entry in sitemap.xml
//
// Cards are screenshot-first: the image fills the top of the card, a thin text
// strip sits below. The big number lives inside the screenshot, not the text.
//
// Fields:
//   slug        url segment, e.g. "example-project" -> /work/example-project
//   label       short card title in the text strip
//   tagline     one short line under the label
//   screenshot  filename in /public/img shown full-bleed on the card
//   number      big headline on the DETAIL page hero ("+35%", "3x", ...)
//   metric      one line under the number on the detail hero
//   org         small label (company or product name)
//   size        bento sizing: "sm" | "md" | "lg" | "xl" | "tall" (controls
//               desktop grid span — "tall" is 1 column x 2 rows; order in
//               this array matters for how "tall" packs against neighbors)
//   link        external url (optional; shown as a CTA on the detail page)
//   detail      the detail-page story. Keep the voice: short, concrete, no
//               fluff. Each section is { heading, body } where body is an
//               array of paragraphs. Add screenshots with `images`.
// ---------------------------------------------------------------------------

module.exports = [
  {
    slug: "example-project",
    label: "Example project",
    tagline: "Replace this with a real one line result.",
    screenshot: "example-project.png",
    number: "+00%",
    metric: "the metric that matters",
    org: "Company",
    size: "lg",
    link: null,
    detail: {
      title: "I did this thing",
      lede: "One or two sentences: the problem, what you did, what moved.",
      sections: [
        {
          heading: "The problem",
          body: [
            "What was broken or missing, and why it mattered.",
          ],
        },
        {
          heading: "What I did",
          body: [
            "What you actually did. Be specific about your role.",
          ],
        },
        {
          heading: "What moved",
          body: [
            "The result, in a real number if you have one.",
          ],
        },
      ],
      images: [],
    },
  },
];
