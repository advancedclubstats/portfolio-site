# Portfolio starter

A screenshot-first personal portfolio. Node.js + Express + EJS, one bento
grid of work cards, a detail page per project, and the AI-SEO files
(`llms.txt`, `robots.txt`, `sitemap.xml`) generated from the same data.

## Run it

```
npm install
npm start
```

Open `http://localhost:3000`.

## Edit these two files

- `site.config.js` — your name, role, email, links, and the words on the
  home page (intro, what you do, what you want).
- `content/projects.js` — one object per project. Each one gets a card on
  the home page and a detail page at `/work/<slug>`. The field comments in
  that file explain what each one does, including the bento `size` values
  (`sm` / `md` / `lg` / `xl` / `tall`) and how card order affects layout.

Drop a screenshot for each project into `public/img/` and reference it by
filename from the `screenshot` field.

## Deploy

Anywhere that runs Node. Binds to `process.env.PORT`. Set `SITE_DOMAIN`
(and `SITE_PROTOCOL` if not https) as an env var once you have a domain —
it flows into the canonical URLs, JSON-LD, and the AI-SEO files.
