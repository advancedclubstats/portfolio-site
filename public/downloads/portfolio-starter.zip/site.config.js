// ---------------------------------------------------------------------------
// Site config — the one place to edit identity + domain.
// When you pick your domain, change SITE_DOMAIN below (or set the
// SITE_DOMAIN env var on the server) and everything else updates: the
// Ask-AI prompt, the JSON-LD schema, llms.txt, sitemap, and canonical URLs.
// ---------------------------------------------------------------------------

const SITE_DOMAIN = process.env.SITE_DOMAIN || "your-domain.com";
const PROTOCOL = process.env.SITE_PROTOCOL || "https";

module.exports = {
  name: "Your Name",
  role: "Your Role",
  domain: SITE_DOMAIN,
  baseUrl: `${PROTOCOL}://${SITE_DOMAIN}`,
  email: "you@example.com",
  // Fill these in when ready (leave empty string to hide the link):
  linkedin: process.env.LINKEDIN_URL || "",
  location: "Remote",

  // Short description reused in meta tags, Open Graph, and llms.txt.
  metaDescription:
    "One or two sentences on who you are and what you do. Shown in search results and to AI assistants that read this site.",

  // The prompt visitors send to an AI when they click a footer button.
  // Uses the live domain so the AI has a source to read.
  askAiPrompt: (name, domain) =>
    `Tell me about ${name} based on ${domain}. Summarize who they are, what they do, and how to get in touch.`,

  // Floating nav (the FAB pill). Each item scrolls to a section id on the page.
  nav: [
    { label: "Home", target: "home" },
    { label: "About", target: "about" },
    { label: "Work", target: "work" },
    { label: "Contact", target: "contact" },
  ],

  // --- Page copy (edit these strings to change the words on the page) -------
  // The big intro card. Placeholder copy — rewrite it in your own voice.
  intro: {
    eyebrow: "Your title · what you focus on",
    head: "One sentence that says what you do and why it matters.",
    body: [
      "A short paragraph on your background. Say where you've worked and what you're good at.",
      "A second short paragraph, more specific. What kind of problem do you want to be handed.",
    ],
  },

  whatIDo: [
    "First thing you do well.",
    "Second thing you do well.",
    "Third thing you do well.",
  ],

  whatIWant: [
    "The kind of role you want.",
    "The kind of company or team.",
    "One thing you want to avoid.",
  ],
};
